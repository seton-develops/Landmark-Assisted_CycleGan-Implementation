import torch
import albumentations as A
from albumentations.pytorch import ToTensorV2

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
TRAIN_DIR = "/home/zluan/ECE_228_project/CycleGAN/data/train"
VAL_DIR = "/home/zluan/ECE_228_project/CycleGAN/data/val"
BATCH_SIZE = 1
LEARNING_RATE = 1e-5
#LAMBDA_IDENTITY = 0.0
LAMBDA_CYCLE = 10
LAMBDA_LANDMARK = 100
NUM_WORKERS = 4
NUM_EPOCHS = 40
LOAD_MODEL = True
SAVE_MODEL = True
CHECKPOINT_G_H = "G_H.pth.tar"
CHECKPOINT_G_C = "G_C.pth.tar"
CHECKPOINT_D_H = "D_H.pth.tar"
CHECKPOINT_D_C = "D_C.pth.tar"
CHECKPOINT_C_D_H = "C_D_H.pth.tar"
CHECKPOINT_C_D_C = "C_D_C.pth.tar"

transforms = A.Compose(
    [
        A.Resize(width=128, height=128),
        A.HorizontalFlip(p=0.5),
        A.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5], max_pixel_value=255),
        ToTensorV2(),
     ],
    additional_targets={"image0": "image"},
)
