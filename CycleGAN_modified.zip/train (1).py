import torch
from dataset import Human2CartoonDataset
import sys
from utils import save_checkpoint, load_checkpoint, calculate_error_norm
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
import config
from tqdm import tqdm
from torchvision.utils import save_image
import numpy as np

from model_CGD import ConditionalDiscriminator
from model_D import Discriminator
from model_G import Generator
from model_R import Regressor

def train_fn(disc_H, disc_C, 
             gen_H, gen_C, 
             reg_H, reg_C, 
             cdisc_H, cdisc_C, 
             loader, 
             opt_disc, opt_gen, 
             l1, mse, 
             d_scaler, g_scaler):
    '''
    
    disc_H : human discriminator, disc_C : cartoon discriminator,  
    (The unconditional global discriminator in Landmark-assisted CycleGAN paper.)
    
    gen_H : human generator,gen_C : cartoon generator,
    
    reg_H : human regressor,   reg_C : cartoon regressor,
    (The pre-trained landmark prediction regressor.)
    
    cdisc_H : human conditional discriminator,  cdisc_C : cartoon conditional discriminator,
    (The conditional global discriminator in Landmark-assisted CycleGAN paper.)
    
    loader : dataloader,
    opt_disc : discriminator optimizer,
    opt_gen : generator optimizer,
    l1 : L1 loss,
    mse : MSE/L2 loss,
    d_scaler : discriminator scaler,
    g_scaler : generator scaler
    
    '''
    H_reals = 0
    H_fakes = 0
    C_reals = 0
    C_fakes = 0
    landmark_human_success_flag = 0
    landmark_cartoon_success_flag = 0
    landmark_running_loss = 0
    loop = tqdm(loader, leave=True)
    
    for idx, (human, cartoon, landmark_human, landmark_cartoon) in enumerate(loop):
        cartoon = cartoon.to(config.DEVICE)
        human = human.to(config.DEVICE)
        landmark_human = landmark_human.to(config.DEVICE)
        landmark_cartoon = landmark_cartoon.to(config.DEVICE)
        # Train Discriminators H and C
        
        with torch.cuda.amp.autocast():
            # Train Discriminators for human
            fake_human = gen_H(cartoon)
            D_H_real = disc_H(human)
            D_H_fake = disc_H(fake_human.detach())
            H_reals += D_H_real.mean().item()
            H_fakes += D_H_fake.mean().item()
            # losses
            D_H_real_loss = mse(D_H_real, torch.ones_like(D_H_real))
            D_H_fake_loss = mse(D_H_fake, torch.zeros_like(D_H_fake))
            D_H_loss = D_H_real_loss + D_H_fake_loss
            
            
            # Train Discriminators for cartoon
            fake_cartoon = gen_C(human)
            D_C_real = disc_C(cartoon)
            D_C_fake = disc_C(fake_cartoon.detach())
            C_reals += D_C_real.mean().item()
            C_fakes += D_C_fake.mean().item()
            #losses
            D_C_real_loss = mse(D_C_real, torch.ones_like(D_C_real))
            D_C_fake_loss = mse(D_C_fake, torch.zeros_like(D_C_fake))
            D_C_loss = D_C_real_loss + D_C_fake_loss

            
            
            # Landmark consistency loss
            # Landmark consistency loss for human
            
            landmark_human_pred = reg_H((fake_human.detach()*0.5+0.5)*255)
            landmark_cartoon_pred = reg_C((fake_cartoon.detach()*0.5+0.5)*255)
            '''
            landmark_human_heatmap = np.zeros((128,128,3),dtype=float)
            landmark_human_pred_heatmap = np.zeros((128,128,3),dtype=float)
            landmark_cartoon_heatmap = np.zeros((128,128,3),dtype=float)
            landmark_cartoon_pred_heatmap = np.zeros((128,128,3),dtype=float)
            for j in range(5):
                landmark_human_heatmap[int(landmark_human[0][2*j]),int(landmark_human[0][2*j+1])] = 1
                landmark_human_pred_heatmap[int(landmark_human_pred[0][2*j]),int(landmark_human_pred[0][2*j+1])] = 1
                landmark_cartoon_heatmap[int(landmark_cartoon[0][2*j]),int(landmark_cartoon[0][2*j+1])] = 1
                landmark_cartoon_pred_heatmap[int(landmark_cartoon_pred[0][2*j]),int(landmark_cartoon_pred[0][2*j+1])] = 1
                
            '''    
            landmark_human_error_norm = calculate_error_norm(landmark_human.detach().cpu().numpy(), landmark_human_pred.detach().cpu().numpy())
            landmark_human_loss_arry = np.mean(landmark_human_error_norm) * 100
            landmark_human_loss = torch.tensor(landmark_human_loss_arry)
            # Landmark consistency loss for cartoon
            
            landmark_cartoon_error_norm = calculate_error_norm(landmark_cartoon.detach().cpu().numpy(), landmark_cartoon_pred.detach().cpu().numpy())
            landmark_cartoon_loss_arry = np.mean(landmark_cartoon_error_norm) * 100
            landmark_cartoon_loss = torch.tensor(landmark_cartoon_loss_arry)
            
            
            
            landmark_loss = landmark_human_loss+landmark_cartoon_loss
            '''
            landmark_human_heatmap = torch.tensor(landmark_human_heatmap)
            landmark_human_pred_heatmap = torch.tensor(landmark_human_pred_heatmap)
            landmark_cartoon_heatmap = torch.tensor(landmark_cartoon_heatmap)
            landmark_cartoon_pred_heatmap = torch.tensor(landmark_cartoon_pred_heatmap)
            
            '''
            
            # If landmarks match the labels successfully , it is considered real image, otherwise fake image
            if np.sum(landmark_human_error_norm) < 0.15:
                # the generated image is a success
                #success_img_human = fake_human.detach()
                #fail_img_human = torch.zeros_like(fake_human.detach())

                landmark_human_success_flag += 1
            #else:
                # the generated image is a failure
                #success_img_human = human.detach()
                #fail_img_human = fake_human.detach()

                
            if np.sum(landmark_cartoon_error_norm) < 0.15:
                # the generated image is a success
                #success_img_cartoon = fake_cartoon.detach()
                #fail_img_cartoon = torch.zeros_like(fake_cartoon.detach())
                landmark_cartoon_success_flag += 1
            #else:
                # the generated image is a failure
                #success_img_cartoon = cartoon.detach()
                #fail_img_cartoon = fake_cartoon.detach()
                
            '''

            
            # Train Conditional Discriminators H and C
            # Train Conditional Discriminator for human
            
            C_D_H_real = cdisc_H(torch.mul(real_human.detach(),landmark_human_heatmap))
            C_D_H_fake = cdisc_H(torch.mul(fake_human.detach(),landmark_human_pred_heatmap))
            C_D_H_real_loss = mse(C_D_H_real, torch.zeros_like(C_D_H_real))
            C_D_H_fake_loss = mse(C_D_H_fake, torch.ones_like(C_D_H_real))
            C_D_H_loss = C_D_H_real_loss + C_D_H_fake_loss
            
            
            # Train Conditional Discriminator for cartoon
            C_D_C_real = cdisc_C(torch.mul(real_cartoon.detach(),landmark_cartoon_heatmap)) 
            C_D_C_fake = cdisc_C(torch.mul(fake_cartoon.detach(),landmark_cartoon_pred_heatmap))
            C_D_C_real_loss = mse(C_D_C_real, torch.zeros_like(C_D_C_real))
            C_D_C_fake_loss = mse(C_D_C_fake, torch.ones_like(C_D_C_real))
            C_D_C_loss = C_D_C_real_loss + C_D_C_fake_loss
            
            
            C_D_loss = C_D_H_loss+C_D_C_loss
            '''
            # put it togethor
            D_loss = (D_H_loss + D_C_loss)/2 #+ C_D_loss
            
        opt_disc.zero_grad()
        d_scaler.scale(D_loss).backward()
        d_scaler.step(opt_disc)
        d_scaler.update()

        # Train Generators H and C
        with torch.cuda.amp.autocast():
            # adversarial loss for both generators
            D_H_fake = disc_H(fake_human)
            #C_D_H_fake = cdisc_H(fail_img_human.detach())
            D_C_fake = disc_C(fake_cartoon)
            #C_D_C_fake = cdisc_C(fail_img_cartoon.detach())
            loss_G_H = mse(D_H_fake, torch.ones_like(D_H_fake))#+mse(C_D_H_fake, torch.zeros_like(C_D_H_fake))
            loss_G_C = mse(D_C_fake, torch.ones_like(D_C_fake))#+mse(C_D_C_fake, torch.zeros_like(C_D_C_fake))

            # cycle loss
            cycle_cartoon = gen_C(fake_human)
            cycle_human = gen_H(fake_cartoon)
            cycle_cartoon_loss = l1(cartoon, cycle_cartoon)
            cycle_human_loss = l1(human, cycle_human)
            


            # add all togethor
            G_loss = (
                loss_G_C
                + loss_G_H
                + cycle_cartoon_loss * config.LAMBDA_CYCLE
                + cycle_human_loss * config.LAMBDA_CYCLE
                #+ landmark_loss * config.LAMBDA_LANDMARK
            )
            landmark_running_loss += landmark_loss.item()
        opt_gen.zero_grad()
        g_scaler.scale(G_loss).backward()
        g_scaler.step(opt_gen)
        g_scaler.update()
            
        if idx % 200 == 0:
            save_image(fake_human*0.5+0.5, f"saved_images/human_{idx}.png")
            save_image(fake_cartoon*0.5+0.5, f"saved_images/cartoon_{idx}.png")

        loop.set_postfix(H_real=H_reals/(idx+1), C_real=C_reals/(idx+1),
                         G_loss=G_loss.item()/(idx+1), 
                         D_loss=D_loss.item()/(idx+1),
                         S_H = landmark_human_success_flag, # successful match
                         S_C = landmark_cartoon_success_flag,
                         L = landmark_loss.item() * config.LAMBDA_LANDMARK/(idx+1),
                         #H_arry= landmark_human_loss_arry * config.LAMBDA_LANDMARK/(idx+1)
                                 )
    return landmark_running_loss
            
        
    

def main():
    disc_H = Discriminator(in_channels=3).to(config.DEVICE)
    disc_C = Discriminator(in_channels=3).to(config.DEVICE)
    gen_C = Generator(img_channels=3, num_residuals=9).to(config.DEVICE)
    gen_H = Generator(img_channels=3, num_residuals=9).to(config.DEVICE)
    reg_C = Regressor().to(config.DEVICE)
    reg_C.load_state_dict(torch.load('R_C.pth.tar')["state_dict"])
    reg_H = Regressor().to(config.DEVICE)
    reg_H.load_state_dict(torch.load('R_H.pth.tar')["state_dict"]) 
    cdisc_H = ConditionalDiscriminator(in_channels=3).to(config.DEVICE)
    cdisc_C = ConditionalDiscriminator(in_channels=3).to(config.DEVICE)
    
    
    
    
    opt_disc = optim.Adam(
        list(disc_H.parameters()) + list(disc_C.parameters()),#+ list(cdisc_H.parameters())+ list(cdisc_C.parameters())
        lr=config.LEARNING_RATE,
        betas=(0.5, 0.999),
    )
    opt_gen = optim.Adam(
        list(gen_C.parameters()) + list(gen_H.parameters()),
        lr=config.LEARNING_RATE,
        betas=(0.5, 0.999),
    )

    L1 = nn.L1Loss()
    mse = nn.MSELoss()

    if config.LOAD_MODEL:
        load_checkpoint(
            config.CHECKPOINT_G_H, gen_H, opt_gen, config.LEARNING_RATE,
        )
        load_checkpoint(
            config.CHECKPOINT_G_C, gen_C, opt_gen, config.LEARNING_RATE,
        )
        load_checkpoint(
            config.CHECKPOINT_D_H, disc_H, opt_disc, config.LEARNING_RATE,
        )
        load_checkpoint(
            config.CHECKPOINT_D_C, disc_C, opt_disc, config.LEARNING_RATE,
        )

    dataset = Human2CartoonDataset(
        root_human=config.TRAIN_DIR+"/trainA", 
        root_cartoon=config.TRAIN_DIR+"/trainB", 
        root_landmarks_human=config.TRAIN_DIR+"/trainA_human_landmarks.xlsx", 
        root_landmarks_cartoon=config.TRAIN_DIR+"/trainB_cartoon_landmarks.xlsx", 
        transform=config.transforms
    )
    
    val_dataset = Human2CartoonDataset(
        root_human=config.VAL_DIR+"/valA", 
        root_cartoon=config.VAL_DIR+"/valB", 
        root_landmarks_human=config.VAL_DIR+"/validA_human_landmarks.xlsx", 
        root_landmarks_cartoon=config.VAL_DIR+"/validB_cartoon_landmarks.xlsx", 
        transform=config.transforms
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=1,
        shuffle=False,
        pin_memory=True,
    )
    
    loader = DataLoader(
        dataset,
        batch_size=config.BATCH_SIZE,
        shuffle=True,
        num_workers=config.NUM_WORKERS,
        pin_memory=True
    )
    
    g_scaler = torch.cuda.amp.GradScaler()
    d_scaler = torch.cuda.amp.GradScaler()
    landmark_hold_loss=[]
    for epoch in range(config.NUM_EPOCHS):
        print('Epoch : ', epoch)
        landmark_running_loss=train_fn(disc_H, disc_C, 
                 gen_H, gen_C, 
                 reg_H, reg_C, 
                 cdisc_H, cdisc_C,
                 loader, 
                 opt_disc, opt_gen, 
                 L1, mse, 
                 d_scaler, g_scaler)
        landmark_hold_loss.append(landmark_running_loss)
        print('landmark loss at this epoch : ', landmark_hold_loss[epoch]/4644)
    

        if config.SAVE_MODEL:
            save_checkpoint(gen_H, opt_gen, filename=config.CHECKPOINT_G_H)
            save_checkpoint(gen_C, opt_gen, filename=config.CHECKPOINT_G_C)
            save_checkpoint(disc_H, opt_disc, filename=config.CHECKPOINT_D_H)
            save_checkpoint(disc_C, opt_disc, filename=config.CHECKPOINT_D_C)
            #save_checkpoint(cdisc_H, opt_disc, filename=config.CHECKPOINT_C_D_H)
            #save_checkpoint(cdisc_C, opt_disc, filename=config.CHECKPOINT_C_D_C)


if __name__ == "__main__":
    main()